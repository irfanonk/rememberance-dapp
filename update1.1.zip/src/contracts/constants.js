import Rememberance from "./Rememberance";

export const rememberanceAbi = Rememberance.abi;
//bsc test
// export const rememberanceAddress = "0x97c2E46F5b3dC616E5D2CDF1de52D01Da85D64cb";

// export const startBlockNumber = 18209233;
export const rememberanceAddress = "0x79AF364D09b8005086D5b26C89468f005917a23a";

export const startBlockNumber = 19855748;
